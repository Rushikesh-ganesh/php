
<?php 



class main extends CI_Controller

{
     public function index(){
     	
     	$data['title'] = 'latest students';

          $data['student']=$this->main_model->get_stud();

     	$this->load->view('templets/header');
	   	$this->load->view('pages/index',$data);
	   	$this->load->view('templets/footer');

     }

         public function add(){
          
          $data['title']='add';
            $this->load->library('form_validation');
            $this->form_validation->set_rules('fname','First Name','required');
            $this->form_validation->set_rules('lname','Last name','required');
            $this->form_validation->set_rules('address','Address','required');
            $this->form_validation->set_rules('dob','Date of Birth','required');
            $this->form_validation->set_rules('created_by','created_by');
      

          if($this->form_validation->run()===FALSE){
             $this->load->view('templets/header');
             $this->load->view('pages/add',$data);
             $this->load->view('templets/footer');
          }else{
                $this->main_model->add_stud();
                $this->session->set_flashdata('user_registered','student are sucessfully registered ');
                redirect('main');
          }
          

     } 


     public function edit($id)
     { 

         $this->load->model('main_model','stud');
         $stud=$this->stud->f_id($id);


         $this->load->view('templets/header');
        $this->load->view('pages/edit',['stud'=>$stud]);
         $this->load->view('templets/footer');


     }

     public function update()
     {
      $this->load->library('form_validation');
      $this->main_model->update_stud();
      $this->session->set_flashdata('user_registered','student are sucessfully updated ');
      redirect('main');
     }

 public function delete($id)

    {

        $this->main_model->delete_stud($id);
      $this->session->set_flashdata('user_registered','student are sucessfully Deleted ');
      redirect('main');

    }



}


 

?>