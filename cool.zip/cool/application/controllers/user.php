<?php
class user extends CI_Controller{
	



public function register(){
		
		$data['title']='sign up';

		$this->load->library('form_validation');
		$this->form_validation->set_rules('username','User Name','required|callback_check_username_exists');
		$this->form_validation->set_rules('email','Email','required|callback_check_email_exists');
		$this->form_validation->set_rules('password','Password','required');
        $this->form_validation->set_rules('password2','Confirm Password','matches[password]');
        $this->form_validation->set_rules('usertype','Usertype','required');
		if($this->form_validation->run()==FALSE){
		   $this->load->view('templets/header');
		   $this->load->view('user/register');
		   $this->load->view('templets/footer');
		}else{
			$enc_password=md5($this->input->post('password'));
			$this->user_model->register($enc_password);

			$this->session->set_flashdata('user_registered','you are sucessfully registered ready for log in');
			redirect('home');
		
		}


	}


public function login(){
		
		$data['title']='sign in';

		$this->load->library('form_validation');
		$this->form_validation->set_rules('username','User Name','required');
		
		$this->form_validation->set_rules('password','Password','required');
       

		if($this->form_validation->run()==FALSE){
		   $this->load->view('templets/header');
		   $this->load->view('user/login');
		   $this->load->view('templets/footer');
		}else{

				$username=$this->input->post('username');
				$password=md5($this->input->post('password'));
				$usertype=$this->input->post('usertype');
				$user_id=$this->user_model->login($username,$password,$usertype);
				if($user_id){
					$user_data=array(
					'user_id'=>$user_id,
					'username'=>$username,
					'usertype'=>$usertype,
					'logged_in'=>true,
					
				);
					

			    	
			    		$this->session->set_userdata($user_data);

		        	 $this->session->set_flashdata('user_login','you are sucessfully log in');
		     	    redirect('main');
				}else
				{
		           $this->session->set_flashdata('login_failed','invalid username or password');
			       redirect('user/login');
				}

			
		
		}




	}



	public function logout(){
		$this->session->unset_userdata('logged_in');
			$this->session->unset_userdata('user_id');
				$this->session->unset_userdata('username');
				$this->session->unset_userdata('usertype');

				
 $this->session->set_flashdata('user_logout','you are sucessfully log out');

 redirect('user/login');
	}
	function check_username_exists($username)
	{
		$this->form_validation->set_message('check_username_exists','That username taken.please take different');
		if($this->user_model->check_username_exists($username)){
			return true;
		}else{
			return false;
		}
		
}
 function check_email_exists($email)
	{
		$this->form_validation->set_message('check_email_exists','That email id already registred .please take different');
		if($this->user_model->check_email_exists($email)){
			return true;
		}else{
			return false;
		}

	}
	



	}



?>
