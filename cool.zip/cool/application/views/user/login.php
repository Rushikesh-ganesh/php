<?php echo validation_errors(); ?>
<?php echo form_open('user/login'); ?>


<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<style>
		.button{
			width: 30%;
		}
		
		
	</style>
</head>
<body>
	<h2>LOGIN PAGE</h2>	
		<center>
			
				<form>
					<div class="form-group" >
					<label>Username :</label><br>
					<input type="text" name="username" id="name" size="43" ><br >
					</div>
					<div class="form-group"  >
					<label >Password :</label><br>
					<input type="password" name="password" id="password"size="43" ><br></div>
                   
                   <div class="form-group" >
                   	<label >Usertype:</label>
					<select name="usertype" style="" >
                      <option value="">select</option>
                      <option value="superadmin">Super Admin</option>
 					  <option value="admin">Admin</option>
 					</select>
 					</div>

					
					<div class="button">
				   <button class="btn btn-primary btn-block" name="submit">Login</button>
				   <button class="btn btn-primary btn-block">
					<a href="<?php echo base_url(); ?>user/register"style="color:white;">register</a></button>
					</div>
					<div class="checkbox">
					<br><label><input type="checkbox"> Remember me</label>
					</div>
				
				</form>
			
		</center>

</body>
</html>

<?php echo form_close();?>

