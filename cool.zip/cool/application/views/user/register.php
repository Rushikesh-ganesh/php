
<?php echo validation_errors(); ?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
  <style>
  	
  	.button{
			width: 30%;
		}
		select
		{
			width: 30%;
		}
  </style>  
		
</head>
<body>
<?php echo form_open('user/register');?>

<h2 style="text-align: center;">REGISTRATION FORM</h2>
<center>  
<!-- <form class="form-horizontal"> -->
<div class="form-group"> 
<label>User Name :</label><br>
<input type="text" name="username" id="name" size="43"></div>
<div class="form-group">
<label>Email :</label><br>
<input type="email" name="email" id="name"   size="43"></div>
<div class="form-group">
<label>Password :</label><br>
<input type="password" name="password" id="password"  size="43" ></div>
<div class="form-group">
<label>Password Confirm :</label><br>
<input type="password" name="password2" id="password"  size="43" ></div>
<div class="form-group">
<label>Select Usertype</label><br>


<select name="usertype">
  <option value="">select</option>
  <option value="superadmin">Super Admin</option>
  <option value="admin">Admin</option>

  
</select><br>


<div class="button">
 <br> <button class="btn btn-primary btn-block" value="Register" name="submit">Register</button><br>
</div>
</form>
</center>  
<?php echo form_close();?>
</body>
</html>



