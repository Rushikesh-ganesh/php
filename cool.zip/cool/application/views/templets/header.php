<html>
  <head>
      <title>My Project</title>
  <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.1.3/cosmo/bootstrap.min.css" rel="stylesheet" integrity="sha384-3Ivskwia8Fui5tbQi+RW4DgTkJ8d+hW7mLe7Yk89ibmD9482VECh0WFof8kIEjwI" crossorigin="anonymous">
 
  </head>
  <body>
    <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="">The School System</a>
    </div>
    <ul class="navbar-header">
    
     <?php if(!$this->session->userdata('logged_in')): ?>
       <a href="<?php echo base_url(); ?> ">Home</a>
       <a href="<?php echo base_url(); ?>user/login">Login</a>
       <a href="<?php echo base_url(); ?>user/register">Register</a>
     <?php endif;?>
     
     <?php if($this->session->userdata('logged_in')): ?>  
     <a href="<?php echo base_url(); ?>user/logout">logout</a>
      <?php echo $this->session->userdata('usertype'); ?>  
       <?php endif; ?>
   </ul>
   </ul>
  </div>
</nav>
<div class="container">
  <hr>
<?php if($this->session->flashdata('user_registered')): ?>
  <?php echo '<p class= "alert alert-success">'.$this->session->flashdata('user_registered').'</p>'; ?>
  <?php endif;?>

  <?php if($this->session->flashdata('login_failed')): ?>
  <?php echo '<p class= "alert alert-danger">'.$this->session->flashdata('login_failed').'</p>'; ?>
  <?php endif;?>

  <?php if($this->session->flashdata('user_login')): ?>
  <?php echo '<p class= "alert alert-success">'.$this->session->flashdata('user_login').'</p>'; ?>
  <?php endif;?>

  <?php if($this->session->flashdata('user_logout')): ?>
  <?php echo '<p class= "alert alert-success">'.$this->session->flashdata('user_logout').'</p>'; ?>
  <?php endif;?>