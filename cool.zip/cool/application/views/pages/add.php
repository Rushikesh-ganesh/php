<!DOCTYPE html>
<html>
<head>
    <title></title>
  <style>
  	
  	.button{
			width: 30%;
		}
		select
		{
			width: 30%;
		}
  </style>  
		
</head>
<body>


  <?php echo validation_errors(); ?>
<?php echo form_open('main/add');?>

<h2 style="text-align: center;">add Student</h2>
<center>  
<!-- <form class="form-horizontal"> -->
<div class="form-group"> 
<label>First Name :</label><br>
<input type="text" name="fname"  size="43" value="<?php echo set_value('fname'); ?>"></div>
<div class="form-group">

<div class="form-group"> 
<label>last Name :</label><br>
<input type="text" name="lname"  size="43" value="<?php echo set_value('lname'); ?>" ></div>
<div class="form-group">

  <div class="form-group"> 
<label>Address :</label><br>
<input type="text" name="address"  size="43" value="<?php echo set_value('address'); ?>"></div>
<div class="form-group">

<label>Date of Birth :</label><br>
<input type="date" name="dob"   size="43" value="<?php echo set_value('dob'); ?>"></div>
<div class="form-group">

<input type="text" name="created_by" value = "<?php if($this->session->userdata('usertype')=='superadmin')
                                                   {
                                                      echo  $this->session->userdata('usertype');     
                                                   }
                                                   
                                                   ?>" hidden>

<div class="button">
 <br> <button class="btn btn-primary btn-block"  name="submit">submit</button><br>
</div>
</form>
</center>  
<?php echo form_close();?>
</body>
</html>
