<!DOCTYPE html>
<html>
<head>
	<title>home page</title>
   
</head>

<center><button class="btn-primary"><a href="<?php echo base_url(); ?>user/login"style="color:white;">Login</a></button>
<button class="btn-primary"><a href="<?php echo base_url(); ?>user/register"style="color:white;">register</a></button></center>
<h1 style="text-align: center;">THE CRUD SYSTEM FOR SCHOOL  </h1>
 
 <p style="text-align: center;">THIS IS SCHOOL MANGMENT SYSTEM FOR SHOWING MARKS OF STUDENTS AND ADDING NEW STUDENT DETAILS FOR HIS ACADMIC SESSION</p>
<body>

</body>
</html>