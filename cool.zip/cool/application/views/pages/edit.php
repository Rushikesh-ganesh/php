<!DOCTYPE html>
<html>
<head>
    <title></title>
  <style>
  	
  	.button{
			width: 30%;
		}
		select
		{
			width: 30%;
		}
  </style>  
		
</head>
<body>


  <?php echo validation_errors(); ?>
<?php echo form_open('main/update');?>

<h2 style="text-align: center;">add Student</h2>
<center>  
<!-- <form class="form-horizontal"> -->

<input type="hidden" name="id" value="<?php echo $stud->id; ?>" >

<div class="form-group"> 
<label>First Name :</label><br>
<input type="text" name="fname"  size="43" value="<?php echo $stud->fname; ?>" ></div>
<div class="form-group">

<div class="form-group"> 
<label>last Name :</label><br>
<input type="text" name="lname"  size="43" value="<?php echo $stud->lname; ?>"  ></div>
<div class="form-group">

  <div class="form-group"> 
<label>Address :</label><br>
<input type="text" name="address"  size="43" value="<?php echo $stud->address; ?>"   > </div>
<div class="form-group">

<label>Date of Birth :</label><br>
<input type="date" name="dob"   size="43" value="<?php echo $stud->dob; ?>"  ></div>
<div class="form-group">

<div class="button">
 <br> <button class="btn btn-primary btn-block"  name="submit">submit</button><br>
</div>
</form>
</center>  
<?php echo form_close();?>
</body>
</html>
