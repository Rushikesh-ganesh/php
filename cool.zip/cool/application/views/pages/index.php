<html>
<head>
	<title>dashboard</title>
<style>
	
.button{
			width: 30%;
		}

</style>

</head>
<body>
	<center>
			<form>
				<h2> STUDENT INFORMATION </h2>
					<div class="button">
 					<br> <button class="btn btn-primary btn-block" name="submit">
 					   <a href="<?php echo base_url(); ?>add"  style="color:white; ">  Add Student</a></button><br>
					</div>	

					<table border="1">  
					      
					         <tr>  
					             <th>First Name</th>  
					             <th>Last name</th> 
					             <th>address</th> 
					             <th> Date of birth</th> 
					             <th>created by</th> 
					             	<th>edit</th>
					               <?php if($this->session->userdata('usertype')=='superadmin'):?>
					               	
					                <th>delete</th> 
					              <?php  endif; ?>


					      		 </tr>
					    		 <?php foreach ($student as $row): ?>
					      		 
					            <tr>
								<td><?php echo $row['fname']; ?></td>
								 <td><?php echo $row['lname']; ?></td>
								 <td><?php echo $row['address']; ?></td>
								 <td><?php echo $row['dob']; ?></td>
								 <td><?php echo $row['created_by']; ?></td>

						     <td>
						    <button class="btn btn-primary btn-block" name="submit">
 					        <a href="<?php echo base_url('main/edit/'.$row['id']); ?>"  style="color:white; ">edit</a></button></td>
 					        	

                            <?php if($this->session->userdata('usertype')=='superadmin'):?>

 					    


 					        <td>
							 <button class="btn btn-danger btn-block" type="delete">
                    	 <a href= "<?php echo base_url('main/delete/'.$row['id']); ?>" onClick="return doconfirm();" style="color:white;  ">delete</a></button>

 					        	<script>
                               function doconfirm()
                                {
                                    job=confirm("Are you sure to delete permanently?");
                                    if(job!=true)
                                      {
                                       return false;
                                      }
                                 }
									
									</script>
									 </td>


									    <?php endif; ?>
					 			 </tr>



					       <?php  endforeach; ?>
					   


					   </table>  

			</form> 
		</center>
</body>
</html>
