<?php
class main_model extends CI_Model{
	public function __construct(){

		$this->load->database();
	}

	public function get_stud($slug=FALSE){
		if($slug===FALSE){
			$query=$this->db->get('student');
			return $query->result_array();
		}
		$query=$this->db->get_where('student',array('slug'=>$slug));
		return $query->result_array();
	}

	public function add_stud()
	{
		$slug=url_title($this->input->post('title'));
		$data=array(
					'fname'=>$this->input->post('fname'),
					'lname'=>$this->input->post('lname'),
					'address'=>$this->input->post('address'),
					'dob'=>$this->input->post('dob'),
					'created_by'=>$this->input->post('created_by'),
		          );

		return $this->db->insert('student',$data);
	}

	public function f_id($id)
	{
	  $q=$this->db->select(['id','fname','lname','address','dob','created_by'])
				->where('id',$id)
				->get('student');

		return $q->row();

	}

	public function update_stud()
	{
		$data = array(
					'fname'=>$this->input->post('fname'),
					'lname'=>$this->input->post('lname'),
					'address'=>$this->input->post('address'),
					'dob'=>$this->input->post('dob'),


		);
		$this->db->where('id',$this->input->post('id'));	
		return $this->db->update('student',$data);
	}
	


	public function delete_stud($id){
		$this->db->where('id',$id);
		$this->db->delete('student');
		return true;
	}

	

}

?>